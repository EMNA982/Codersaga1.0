// src/main.ts
import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { AppComponent } from './app/app.component';

// Seed localStorage au démarrage (si tu utilises db.ts)
import { seedLocalStorageOnce } from './app/mock/db';
seedLocalStorageOnce();

bootstrapApplication(AppComponent, appConfig)
  .catch((err) => console.error(err));