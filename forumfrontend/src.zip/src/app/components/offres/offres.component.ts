import { Component } from '@angular/core';

@Component({
  selector: 'app-offres',
  imports: [],
  templateUrl: './offres.component.html',
  styleUrl: './offres.component.css'
})
export class OffresComponent {

}
