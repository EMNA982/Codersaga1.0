import { Component } from '@angular/core';

@Component({
  selector: 'app-signup-company',
  imports: [],
  templateUrl: './signup-company.component.html',
  styleUrl: './signup-company.component.css'
})
export class SignupCompanyComponent {

}
