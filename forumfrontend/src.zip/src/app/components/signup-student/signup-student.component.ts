import { Component } from '@angular/core';

@Component({
  selector: 'app-signup-student',
  imports: [],
  templateUrl: './signup-student.component.html',
  styleUrl: './signup-student.component.css'
})
export class SignupStudentComponent {

}
