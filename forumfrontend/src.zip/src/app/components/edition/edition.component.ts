import { Component } from '@angular/core';

@Component({
  selector: 'app-edition',
  imports: [],
  templateUrl: './edition.component.html',
  styleUrl: './edition.component.css'
})
export class EditionComponent {

}
