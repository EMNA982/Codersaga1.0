import { Routes } from '@angular/router';

import { PageAcceuilComponent } from './components/page-acceuil/page-acceuil.component';
import { EditionComponent } from './components/edition/edition.component'; // si tu l'utilises
import { OffresComponent } from './components/offres/offres.component';     // si existant
import { LoginComponent } from './components/login/login.component';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { CompanyDashboardComponent } from './components/company-dashboard/company-dashboard.component';
import { StudentDashboardComponent } from './components/student-dashboard/student-dashboard.component';

// Nouveaux composants standalone
import { EditionsListComponent } from './pages/editions/editions-list/editions-list.component';
import { OffresListComponent } from './pages/student/offres-list/offres-list.component';
import { OffreDetailsComponent } from './pages/student/offre-details/offre-details.component';
import { MesCandidaturesComponent } from './pages/student/mes-candidatures/mes-candidatures.component';
import { CompanyOffresListComponent } from './pages/Company/company-offres-list/company-offres-list.component';
import { CompanyOffreFormComponent } from './pages/Company/company-offre-form/company-offre-form.component'; 
import { CompanyCandidaturesComponent } from './pages/Company/company-candidatures/company-candidatures.component';
import { AdminEntreprisesComponent } from './pages/Admin/admin-entreprises/admin-entreprises.component';
import { AdminOffresComponent } from './pages/Admin/admin-offres/admin-offres.component'; 
import { AdminCandidaturesComponent } from './pages/Admin/admin-candidatures/admin-candidatures.component'; 
import { AdminStatsComponent } from './pages/Admin/admin-stats/admin-stats.component'; 
import { RegisterStudentComponent } from './pages/auth/register-student/register-student.component'; 
import { RegisterCompanyComponent } from './pages/auth/register-company/register-company.component'; 

export const routes: Routes = [
  { path: '', component: PageAcceuilComponent },
  { path: 'editions', component: EditionsListComponent },

  // Auth
  { path: 'login', component: LoginComponent },
  { path: 'signup-student', component: RegisterStudentComponent },
  { path: 'signup-company', component: RegisterCompanyComponent },

  // Student
  { path: 'student-dashboard', component: StudentDashboardComponent, children: [
    { path: '', redirectTo: 'offres', pathMatch: 'full' },
    { path: 'offres', component: OffresListComponent },
    { path: 'offre/:id', component: OffreDetailsComponent },
    { path: 'candidatures', component: MesCandidaturesComponent },
  ]},

  // Company
  { path: 'company-dashboard', component: CompanyDashboardComponent, children: [
    { path: '', redirectTo: 'offres', pathMatch: 'full' },
    { path: 'offres', component: CompanyOffresListComponent },
    { path: 'offres/nouveau', component: CompanyOffreFormComponent },
    { path: 'candidatures', component: CompanyCandidaturesComponent },
  ]},

  // Admin
  { path: 'admin-dashboard', component: AdminDashboardComponent, children: [
    { path: '', redirectTo: 'stats', pathMatch: 'full' },
    { path: 'entreprises', component: AdminEntreprisesComponent },
    { path: 'offres', component: AdminOffresComponent },
    { path: 'candidatures', component: AdminCandidaturesComponent },
    { path: 'stats', component: AdminStatsComponent },
  ]},

  { path: '**', redirectTo: '' }
];
