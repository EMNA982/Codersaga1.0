import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Entreprise } from '../models/entreprise.model';

@Injectable({ providedIn: 'root' })
export class EntreprisesService {
  private key = 'entreprises';
  private _items$ = new BehaviorSubject<Entreprise[]>(this.read());
  items$ = this._items$.asObservable();

  private read(): Entreprise[] {
    return JSON.parse(localStorage.getItem(this.key) || '[]');
  }
  private write(data: Entreprise[]) {
    localStorage.setItem(this.key, JSON.stringify(data));
  }

  getAll() {
    return this._items$.value;
  }

  create(e: Omit<Entreprise, 'id'>) {
    const data = this.read();
    const id = data.length ? Math.max(...data.map(d => d.id)) + 1 : 1;

    const newEnt: Entreprise = { id, ...e };
    data.push(newEnt);

    this.write(data);
    this._items$.next(data);

    return newEnt;
  }

  delete(id: number) {
    const data = this.read().filter(x => x.id !== id);
    this.write(data);
    this._items$.next(data);
}
}