import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Candidature, CandidatureStatus } from '../models/candidature.model';

@Injectable({ providedIn: 'root' })
export class CandidaturesService {
  private key = 'candidatures';
  private _items$ = new BehaviorSubject<Candidature[]>(this.read());
  items$ = this._items$.asObservable();

  private read(): Candidature[] {
    return JSON.parse(localStorage.getItem(this.key) || '[]');
  }
  private write(data: Candidature[]) {
    localStorage.setItem(this.key, JSON.stringify(data));
  }

  getAll() {
    return this._items$.value;
  }

  getByEtudiant(id: number) {
    return this._items$.value.filter(c => c.etudiantId === id);
  }

  create(input: Omit<Candidature, 'id' | 'submittedAt' | 'status'>) {
    const data = this.read();
    const id = data.length ? Math.max(...data.map(c => c.id)) + 1 : 1;

    const newCand: Candidature = {
      ...input,
      id,
      status: 'en_attente',
      submittedAt: new Date().toISOString(),
    };

    data.push(newCand);
    this.write(data);
    this._items$.next(data);

    return newCand;
  }

  setStatus(id: number, status: CandidatureStatus) {
    const updated = this.read().map(c =>
      c.id === id ? { ...c, status } : c
    );
    this.write(updated);
    this._items$.next(updated);
  }
}
