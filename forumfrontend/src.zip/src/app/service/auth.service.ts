import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { User, UserRole } from '../models/user.model';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private usersKey = 'users';
  private sessionKey = 'session';

  private _user$ = new BehaviorSubject<User | null>(this.readSession());
  user$ = this._user$.asObservable();

  private readUsers(): User[] {
    return JSON.parse(localStorage.getItem(this.usersKey) || '[]');
  }
  private writeUsers(data: User[]) {
    localStorage.setItem(this.usersKey, JSON.stringify(data));
  }

  private readSession(): User | null {
    return JSON.parse(localStorage.getItem(this.sessionKey) || 'null');
  }
  private writeSession(user: User | null) {
    if (user) localStorage.setItem(this.sessionKey, JSON.stringify(user));
    else localStorage.removeItem(this.sessionKey);
  }

  login(email: string, password: string): User | null {
    const user = this.readUsers().find(u => u.email === email && u.password === password) || null;
    this._user$.next(user);
    this.writeSession(user);
    return user;
  }

  logout() {
    this._user$.next(null);
    this.writeSession(null);
  }

  register(role: UserRole, email: string, password: string, displayName: string, entrepriseId?: number): User {
    const users = this.readUsers();
    const id = users.length ? Math.max(...users.map(u => u.id)) + 1 : 1;

    const newUser: User = {
      id,
      role,
      email,
      password,
      displayName,
      entrepriseId,
    };

    users.push(newUser);
    this.writeUsers(users);
    return newUser;
  }

  getCurrentUser(): User | null {
    return this._user$.value;
  }

  is(role: UserRole): boolean {
    return this._user$.value?.role === role;
  }
}