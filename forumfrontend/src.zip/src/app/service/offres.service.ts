import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Offre } from '../models/offre.model';

@Injectable({ providedIn: 'root' })
export class OffresService {
  private key = 'offres';
  private _offres$ = new BehaviorSubject<Offre[]>(this.read());
  offres$ = this._offres$.asObservable();

  private read(): Offre[] {
    return JSON.parse(localStorage.getItem(this.key) || '[]');
  }
  private write(data: Offre[]) {
    localStorage.setItem(this.key, JSON.stringify(data));
  }

  getAll() {
    return this._offres$.value;
  }

  getById(id: number) {
    return this._offres$.value.find(o => o.id === id);
  }

  getByEntreprise(entrepriseId: number) {
    return this._offres$.value.filter(o => o.entrepriseId === entrepriseId);
  }

  create(offre: Omit<Offre, 'id' | 'dateAjout'>): Offre {
    const data = this.read();
    const id = data.length ? Math.max(...data.map(d => d.id)) + 1 : 1;

    const newOffre: Offre = {
      ...offre,
      id,
      dateAjout: new Date().toISOString(),
    };

    data.push(newOffre);
    this.write(data);
    this._offres$.next(data);

    return newOffre;
  }

  delete(id: number) {
    const updated = this.read().filter(o => o.id !== id);
    this.write(updated);
    this._offres$.next(updated);
  }
}
``