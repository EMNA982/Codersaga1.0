import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Edition } from '../models/edition.model';

@Injectable({ providedIn: 'root' })
export class EditionsService {
  private key = 'editions';
  private _items$ = new BehaviorSubject<Edition[]>(this.read());
  items$ = this._items$.asObservable();

  private read(): Edition[] {
    return JSON.parse(localStorage.getItem(this.key) || '[]');
  }
}