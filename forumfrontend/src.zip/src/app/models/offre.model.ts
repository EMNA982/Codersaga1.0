export type OffreType = 'PFE' | 'Stage' | 'Emploi';

export interface Offre {
  id: number;
  titre: string;
  type: OffreType;
  description: string;
  entrepriseId: number;
  dateAjout: string; 
  localisation?: string;
  skills?: string[];
}