export type UserRole = 'student' | 'company' | 'admin';

export interface User {
  id: number;
  role: UserRole;
  email: string;
  password: string;
  displayName: string;
  entrepriseId?: number;
}