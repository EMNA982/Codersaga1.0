export interface Edition {
  id: number;
  titre: string;
  annee: number;
  image: string;
  resume?: string;
}
``