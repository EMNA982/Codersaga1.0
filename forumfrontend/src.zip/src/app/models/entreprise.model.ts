export interface Entreprise {
  id: number;
  nom: string;
  logo?: string;
  email: string;
  site?: string;
  verified?: boolean;
}
