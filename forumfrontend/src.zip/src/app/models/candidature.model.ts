export type CandidatureStatus = 'en_attente' | 'acceptee' | 'refusee';

export interface Candidature {
  id: number;
  etudiantId: number;
  offreId: number;
  status: CandidatureStatus;
  submittedAt: string;
}