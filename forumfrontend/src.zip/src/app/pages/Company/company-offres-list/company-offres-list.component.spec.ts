import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CompanyOffresListComponent } from './company-offres-list.component';

describe('CompanyOffresListComponent', () => {
  let component: CompanyOffresListComponent;
  let fixture: ComponentFixture<CompanyOffresListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CompanyOffresListComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CompanyOffresListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
