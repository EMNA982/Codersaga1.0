// src/app/pages/company/company-offres-list/company-offres-list.component.ts
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../../service/auth.service'; 
import { OffresService } from '../../../service/offres.service';
import { Offre } from '../../../models/offre.model';

@Component({
  selector: 'app-company-offres-list',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './company-offres-list.component.html',
  styleUrls: ['./company-offres-list.component.css']
})
export class CompanyOffresListComponent {
  user: any;
  offres: Offre[] = [];

  constructor(private auth: AuthService, private offresService: OffresService) {
    this.user = this.auth.getCurrentUser();
    if (this.user?.entrepriseId) {
      this.offres = this.offresService.getByEntreprise(this.user.entrepriseId);
    }
  }

  delete(id: number) {
    if (!confirm('Supprimer cette offre ?')) return;
    this.offresService.delete(id);
    if (this.user?.entrepriseId) {
      this.offres = this.offresService.getByEntreprise(this.user.entrepriseId);
    }
  }
}