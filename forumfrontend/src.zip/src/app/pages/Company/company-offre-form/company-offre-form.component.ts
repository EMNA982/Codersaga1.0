// src/app/pages/company/company-offre-form/company-offre-form.component.ts
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { OffresService } from '../../../service/offres.service'; 
import { AuthService } from '../../../service/auth.service'; 

@Component({
  selector: 'app-company-offre-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './company-offre-form.component.html',
  styleUrls: ['./company-offre-form.component.css']
})
export class CompanyOffreFormComponent {
  form!: FormGroup;

  constructor(
    private fb: FormBuilder,
    private offres: OffresService,
    private auth: AuthService,
    private router: Router
  ) {
    this.form = this.fb.group({
      titre: ['', [Validators.required, Validators.minLength(4)]],
      type: ['PFE', Validators.required],
      description: ['', [Validators.required, Validators.minLength(10)]],
      localisation: [''],
      skills: ['Angular, IA']
    });
  }

  submit() {
    const user = this.auth.getCurrentUser();
    if (!user || user.role !== 'company' || !user.entrepriseId) return alert('Connectez-vous en tant qu’entreprise.');
    if (this.form.invalid) return this.form.markAllAsTouched();

    const v = this.form.value;
    this.offres.create({
      titre: v.titre!,
      type: v.type as any,
      description: v.description!,
      entrepriseId: user.entrepriseId,
      localisation: v.localisation || '',
      skills: (v.skills || '')
        .split(',')
        .map((s: string) => s.trim())
        .filter(Boolean),
    });

    alert('Offre publiée ✅');
    this.router.navigate(['/company-dashboard/offres']);
  }
}
``