import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CompanyOffreFormComponent } from './company-offre-form.component';

describe('CompanyOffreFormComponent', () => {
  let component: CompanyOffreFormComponent;
  let fixture: ComponentFixture<CompanyOffreFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CompanyOffreFormComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CompanyOffreFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
