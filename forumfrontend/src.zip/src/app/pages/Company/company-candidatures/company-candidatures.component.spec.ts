import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CompanyCandidaturesComponent } from './company-candidatures.component';

describe('CompanyCandidaturesComponent', () => {
  let component: CompanyCandidaturesComponent;
  let fixture: ComponentFixture<CompanyCandidaturesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CompanyCandidaturesComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CompanyCandidaturesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
