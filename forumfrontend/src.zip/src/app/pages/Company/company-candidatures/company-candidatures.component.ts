import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../service/auth.service'; 
import { CandidaturesService } from '../../../service/candidatures.service';
import { OffresService } from '../../../service/offres.service'; 

@Component({
  selector: 'app-company-candidatures',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './company-candidatures.component.html',
  styleUrls: ['./company-candidatures.component.css']
})
export class CompanyCandidaturesComponent {
  items: any[] = [];
  constructor(private auth: AuthService, private cands: CandidaturesService, private offres: OffresService) {
    const u = this.auth.getCurrentUser();
    if (u?.entrepriseId) {
      const ids = this.offres.getByEntreprise(u.entrepriseId).map(o => o.id);
      this.items = this.cands.getAll().filter(c => ids.includes(c.offreId));
    }
  }
  setStatus(id: number, status: 'en_attente'|'acceptee'|'refusee') {
    this.cands.setStatus(id, status);
    const u = this.auth.getCurrentUser();
    if (u?.entrepriseId) {
      const ids = this.offres.getByEntreprise(u.entrepriseId).map(o => o.id);
      this.items = this.cands.getAll().filter(c => ids.includes(c.offreId));
    }
  }
}
