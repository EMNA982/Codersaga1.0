// src/app/pages/admin/admin-entreprises/admin-entreprises.component.ts
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { EntreprisesService } from '../../../service/entreprises.service'; 
import { Entreprise } from '../../../models/entreprise.model';

@Component({
  selector: 'app-admin-entreprises',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './admin-entreprises.component.html',
  styleUrls: ['./admin-entreprises.component.css']
})
export class AdminEntreprisesComponent {
  entreprises: Entreprise[] = [];
  nom = ''; email = ''; site = ''; logo = '';

  constructor(private service: EntreprisesService) {
    this.entreprises = this.service.getAll();
  }

  add() {
    if (!this.nom || !this.email) return;
    this.service.create({ nom: this.nom, email: this.email, site: this.site, logo: this.logo, verified: true });
    this.entreprises = this.service.getAll();
    this.nom = this.email = this.site = this.logo = '';
  }

  remove(id: number) {
    if (!confirm('Supprimer ?')) return;
    this.service.delete(id);  // ← nécessite la méthode dans le service
    this.entreprises = this.service.getAll();
  }
}