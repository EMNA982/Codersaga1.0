import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminEntreprisesComponent } from './admin-entreprises.component';

describe('AdminEntreprisesComponent', () => {
  let component: AdminEntreprisesComponent;
  let fixture: ComponentFixture<AdminEntreprisesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdminEntreprisesComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminEntreprisesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
