import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OffresService } from '../../../service/offres.service'; 
import { CandidaturesService } from '../../../service/candidatures.service';
import { EntreprisesService } from '../../../service/entreprises.service'; 
@Component({
  selector: 'app-admin-stats',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './admin-stats.component.html',
  styleUrls: ['./admin-stats.component.css']
})
export class AdminStatsComponent {
  totalOffres = 0;
  totalCands = 0;
  totalEntreprises = 0;

  constructor(
    private offres: OffresService,
    private cands: CandidaturesService,
    private ents: EntreprisesService
  ) {
    this.totalOffres = this.offres.getAll().length;
    this.totalCands = this.cands.getAll().length;
    this.totalEntreprises = this.ents.getAll().length;
  }
}