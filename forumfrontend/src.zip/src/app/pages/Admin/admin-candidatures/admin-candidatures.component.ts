// src/app/pages/admin/admin-candidatures/admin-candidatures.component.ts
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CandidaturesService } from '../../../service/candidatures.service'; 
import { Candidature } from '../../../models/candidature.model';

@Component({
  selector: 'app-admin-candidatures',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './admin-candidatures.component.html',
  styleUrls: ['./admin-candidatures.component.css']
})
export class AdminCandidaturesComponent {
  cands: Candidature[] = [];
  constructor(private candsService: CandidaturesService) {
    this.cands = this.candsService.getAll();
  }
}