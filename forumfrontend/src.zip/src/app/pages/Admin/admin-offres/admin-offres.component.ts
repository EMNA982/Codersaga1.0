// src/app/pages/admin/admin-offres/admin-offres.component.ts
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OffresService } from '../../../service/offres.service'; 
import { Offre } from '../../../models/offre.model';

@Component({
  selector: 'app-admin-offres',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './admin-offres.component.html',
  styleUrls: ['./admin-offres.component.css']
})
export class AdminOffresComponent {
  offres: Offre[] = [];
  constructor(private offresService: OffresService) {
    this.offres = this.offresService.getAll();
  }
  remove(id: number) {
    if (!confirm('Supprimer cette offre ?')) return;
    this.offresService.delete(id);
    this.offres = this.offresService.getAll();
  }
}