// src/app/pages/editions/editions-list/editions-list.component.ts
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EditionsService } from '../../../service/editions.service'; 
import { Observable } from 'rxjs';
import { Edition } from '../../../models/edition.model';

@Component({
  selector: 'app-editions-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './editions-list.component.html',
  styleUrls: ['./editions-list.component.css']
})
export class EditionsListComponent {
  editions$!: Observable<Edition[]>;
  constructor(private editions: EditionsService) {
    this.editions$ = this.editions.items$;
  }
}