// src/app/pages/auth/register-company/register-company.component.ts
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../../service/auth.service'; 
import { EntreprisesService } from '../../../service/entreprises.service';

@Component({
  selector: 'app-register-company',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './register-company.component.html',
  styleUrls: ['./register-company.component.css']
})
export class RegisterCompanyComponent {
  form!: FormGroup;
  submitting = false;

  constructor(
    private fb: FormBuilder,
    private auth: AuthService,
    private ents: EntreprisesService,
    private router: Router
  ) {
    this.form = this.fb.group({
      entrepriseNom: ['', [Validators.required, Validators.minLength(2)]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
    });
  }

  submit() {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    const v = this.form.value;
    const ent = this.ents.create({ nom: v.entrepriseNom!, email: v.email!, verified: false });
    this.auth.register('company', v.email!, v.password!, v.entrepriseNom!, ent.id);
    alert('Compte entreprise créé ✅');
    this.router.navigate(['/login']);
  }
}
