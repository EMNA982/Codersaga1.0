// src/app/pages/student/mes-candidatures/mes-candidatures.component.ts
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../service/auth.service'; 
import { CandidaturesService } from '../../../service/candidatures.service'; 
import { OffresService } from '../../../service/offres.service'; 
import { Candidature } from '../../../models/candidature.model';

@Component({
  selector: 'app-mes-candidatures',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './mes-candidatures.component.html',
  styleUrls: ['./mes-candidatures.component.css']
})
export class MesCandidaturesComponent {
  user: any;
  cands: Candidature[] = [];

  constructor(
    private auth: AuthService,
    private candidatures: CandidaturesService,
    private offres: OffresService
  ) {
    this.user = this.auth.getCurrentUser();
    this.cands = this.user ? this.candidatures.getByEtudiant(this.user.id) : [];
  }

  titreOffre(id: number) {
    return this.offres.getById(id)?.titre || 'Offre';
  }
}