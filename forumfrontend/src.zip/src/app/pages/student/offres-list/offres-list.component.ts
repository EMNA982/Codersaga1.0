// src/app/pages/student/offres-list/offres-list.component.ts
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { OffresService } from '../../../service/offres.service';
import { EntreprisesService } from '../../../service/entreprises.service'; 
import { Offre } from '../../../models/offre.model';
import { Entreprise } from '../../../models/entreprise.model';

@Component({
  selector: 'app-offres-list',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './offres-list.component.html',
  styleUrls: ['./offres-list.component.css']
})
export class OffresListComponent {
  offres: Offre[] = [];
  entreprises: Entreprise[] = [];

  constructor(
    private offresService: OffresService,
    private entreprisesService: EntreprisesService
  ) {
    this.offres = this.offresService.getAll();
    this.entreprises = this.entreprisesService.getAll();
  }

  nomEntreprise(id: number) {
    return this.entreprises.find(e => e.id === id)?.nom || 'Entreprise';
  }
}
``