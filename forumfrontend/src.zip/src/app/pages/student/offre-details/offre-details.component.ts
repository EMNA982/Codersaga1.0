// src/app/pages/student/offre-details/offre-details.component.ts
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { OffresService } from '../../../service/offres.service'; 
import { CandidaturesService } from '../../../service/candidatures.service'; 
import { AuthService } from '../../../service/auth.service'; 
import { Offre } from '../../../models/offre.model';

@Component({
  selector: 'app-offre-details',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './offre-details.component.html',
  styleUrls: ['./offre-details.component.css']
})
export class OffreDetailsComponent {
  offre?: Offre;

  constructor(
    private route: ActivatedRoute,
    private offres: OffresService,
    private cands: CandidaturesService,
    private auth: AuthService
  ) {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.offre = this.offres.getById(id);
  }

  postuler() {
    const user = this.auth.getCurrentUser();
    if (!user || user.role !== 'student' || !this.offre) return alert('Connectez-vous en tant qu’étudiant.');
    this.cands.create({ etudiantId: user.id, offreId: this.offre.id });
    alert('Candidature envoyée ✅');
  }
}