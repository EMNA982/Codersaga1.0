import { Entreprise } from '../models/entreprise.model'; 
import { Offre } from '../models/offre.model'; 
import { Candidature } from '../models/candidature.model'; 
import { User } from '../models/user.model'; 
import { Edition } from '../models/edition.model'; 

const seedEntreprises: Entreprise[] = [
  { id: 1, nom: 'GreenAI Labs', email: 'hr@greenai.tn', site: 'https://greenai.tn', logo: 'assets/images/entreprises/greenai.png', verified: true },
  { id: 2, nom: 'EcoTech', email: 'jobs@ecotech.com', site: 'https://ecotech.com', logo: 'assets/images/entreprises/ecotech.png', verified: true },
];

const seedOffres: Offre[] = [
  { id: 1, titre: 'PFE: Optimisation énergie par IA', type: 'PFE', description: 'Projet PFE IA/GreenTech...', entrepriseId: 1, dateAjout: new Date().toISOString(), localisation: 'Sfax', skills: ['Python','ML','Energy'] },
  { id: 2, titre: 'Stage été: Frontend Angular', type: 'Stage', description: 'Stage été UI/UX + Angular...', entrepriseId: 2, dateAjout: new Date().toISOString(), localisation: 'Tunis', skills: ['Angular','UI'] },
  { id: 3, titre: 'Emploi: Data Engineer Junior', type: 'Emploi', description: 'Pipeline de données durables...', entrepriseId: 1, dateAjout: new Date().toISOString(), localisation: 'Remote', skills: ['Python','ETL','Cloud'] },
];

const seedUsers: User[] = [
  { id: 1, role: 'admin', email: 'admin@forum.tn', password: 'admin', displayName: 'Admin' },
  { id: 2, role: 'student', email: 'etudiant@enetcom.tn', password: '123456', displayName: 'Étudiant Test' },
  { id: 3, role: 'company', email: 'recruteur@greenai.tn', password: '123456', displayName: 'GreenAI HR', entrepriseId: 1 },
];

const seedCandidatures: Candidature[] = [
  { id: 1, etudiantId: 2, offreId: 1, status: 'en_attente', submittedAt: new Date().toISOString() },
];

const seedEditions: Edition[] = [
  { id: 1, titre: '10ᵉ Édition 2024–2025', annee: 2025, image: 'assets/images/editions/2025.jpg', resume: 'Focus IA & GreenTech' },
  { id: 2, titre: '9ᵉ Édition 2023–2024',  annee: 2024, image: 'assets/images/editions/2024.jpg', resume: 'Innovation durable' },
];

export function seedLocalStorageOnce(): void {
  if (!localStorage.getItem('entreprises')) localStorage.setItem('entreprises', JSON.stringify(seedEntreprises));
  if (!localStorage.getItem('offres')) localStorage.setItem('offres', JSON.stringify(seedOffres));
  if (!localStorage.getItem('users')) localStorage.setItem('users', JSON.stringify(seedUsers));
  if (!localStorage.getItem('candidatures')) localStorage.setItem('candidatures', JSON.stringify(seedCandidatures));
  if (!localStorage.getItem('editions')) localStorage.setItem('editions', JSON.stringify(seedEditions));
}